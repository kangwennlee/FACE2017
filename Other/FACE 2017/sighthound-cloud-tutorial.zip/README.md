# Sighthound Cloud Face Recognition API Tutorial

This repository contains code samples and test images to use with the Sighthound Cloud Face Recognition API Tutorial located at https://www.sighthound.com/products/cloud/recognition/tutorial