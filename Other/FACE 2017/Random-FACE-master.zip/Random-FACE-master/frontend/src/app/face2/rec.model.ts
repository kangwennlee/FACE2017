export class Rec {
	public pname;
	public productImage;
	public description;
	public recommendation;

	constructor(pname, productImage, description, recommendation) {
		this.pname = pname;
		this.productImage = productImage;
		this.description = description;
		this.recommendation = recommendation;
	}
}
